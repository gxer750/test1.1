package test.package1;

public class test2 {

    public static void main(String args []) {
        boolean a = false;
        if (a = false)
            System.out.println("Hello");
        else
            System.out.println("Goodbye");
    }

}
