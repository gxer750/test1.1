package test.package1;

public class TestHelloWorld {

    public static void main(String arg[]) {
        System.out.println("Hello Folks!");

        System.out.println("My name is Elias!");

    }
}
